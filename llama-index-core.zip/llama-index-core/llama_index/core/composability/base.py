"""Composable graph."""

# TODO: remove this file, only keep for backwards compatibility
from llama_index.core.indices.composability.graph import ComposableGraph  # noqa
