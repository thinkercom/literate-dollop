from llama_index.core.indices.managed.base import BaseManagedIndex

__all__ = [
    "BaseManagedIndex",
]
