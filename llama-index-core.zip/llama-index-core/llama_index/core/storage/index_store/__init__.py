from llama_index.core.storage.index_store.simple_index_store import (
    SimpleIndexStore,
)

__all__ = [
    "SimpleIndexStore",
]
